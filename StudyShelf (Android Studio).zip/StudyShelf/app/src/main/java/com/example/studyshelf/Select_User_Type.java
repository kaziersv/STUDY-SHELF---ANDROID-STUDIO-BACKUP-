package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Select_User_Type extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_user_type);

        Button btnNavigate = findViewById(R.id.btnNavigate3);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Select_User_Type.this, Login_Teacher.class);
            startActivity(intent);
        });

        Button btnNavigate2 = findViewById(R.id.btnNavigate2);
        btnNavigate2.setOnClickListener(v -> {
            Intent intent = new Intent(Select_User_Type.this, Login_Student.class);
            startActivity(intent);
        });

        ImageButton imageButton9 = findViewById(R.id.imgbtn9);
        imageButton9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Select_User_Type.this, Login_Teacher.class));
            }
        });

        ImageButton imageButton10 = findViewById(R.id.imgbtn10);
        imageButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Select_User_Type.this, Login_Student.class));
            }
        });
    }
}
