package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        Button btnNavigate = findViewById(R.id.btnDoc);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Homepage.this, Folders.class);
            startActivity(intent);

        });

        Button btnNavigate2 = findViewById(R.id.btnCalendar);
        btnNavigate2.setOnClickListener(v -> {
            Intent intent = new Intent(Homepage.this, Schedule.class);
            startActivity(intent);

        });

        Button btnNavigate3 = findViewById(R.id.btnNotes);
        btnNavigate3.setOnClickListener(v -> {
            Intent intent = new Intent(Homepage.this, Notes.class);
            startActivity(intent);

        });

        ImageButton imageButton = findViewById(R.id.imgbtn);
        imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(Homepage.this, Auto_Redirect.class));
                }
        });
    }
}