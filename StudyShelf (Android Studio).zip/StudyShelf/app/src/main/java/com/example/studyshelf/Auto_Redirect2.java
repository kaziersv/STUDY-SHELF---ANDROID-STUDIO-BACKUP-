package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Auto_Redirect2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_redirect2);

        Button btnNavigate = findViewById(R.id.btnLogout2);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Auto_Redirect2.this, Log_Out2.class);
            startActivity(intent);
        });

    }
}