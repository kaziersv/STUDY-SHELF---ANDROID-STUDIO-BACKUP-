package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Schedule2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule2);

        Button btnNavigate = findViewById(R.id.btnHome6);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Schedule2.this, Homepage2.class);
            startActivity(intent);

        });

        Button btnNavigate2 = findViewById(R.id.btnDoc6);
        btnNavigate2.setOnClickListener(v -> {
            Intent intent = new Intent(Schedule2.this, Folders2.class);
            startActivity(intent);

        });

        Button btnNavigate3 = findViewById(R.id.btnNotes6);
        btnNavigate3.setOnClickListener(v -> {
            Intent intent = new Intent(Schedule2.this, Notes2.class);
            startActivity(intent);

        });

        ImageButton imageButton8 = findViewById(R.id.imgbtn8);
        imageButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Schedule2.this, Auto_Redirect2.class));
            }
        });
    }
}