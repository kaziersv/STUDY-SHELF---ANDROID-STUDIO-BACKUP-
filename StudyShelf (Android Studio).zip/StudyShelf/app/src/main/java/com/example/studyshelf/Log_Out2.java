package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Log_Out2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_out2);

        Button btnNavigate = findViewById(R.id.btnYES2);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Log_Out2.this, Welcome_Page.class);
            startActivity(intent);
        });

        Button btnNavigate2 = findViewById(R.id.btnNO2);
        btnNavigate2.setOnClickListener(v -> {
            Intent intent = new Intent(Log_Out2.this, Auto_Redirect2.class);
            startActivity(intent);
        });
    }
}