package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Login_Teacher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_teacher);

        Button btnNavigate = findViewById(R.id.btnLogin);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Login_Teacher.this, Homepage2.class);
            startActivity(intent);
        });

        Button btnNavigate2 = findViewById(R.id.btnSignUp);
        btnNavigate2.setOnClickListener(v -> {
            Intent intent = new Intent(Login_Teacher.this, Sign_Up.class);
            startActivity(intent);

        });
    }
}