package com.example.studyshelf;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.os.IResultReceiver;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Login_Student extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_student);

        Button btnNavigate = findViewById(R.id.btnLogin2);
        btnNavigate.setOnClickListener(v -> {
            Intent intent = new Intent(Login_Student.this, Homepage.class);
            startActivity(intent);
        });

        Button btnNavigate2 = findViewById(R.id.btnSignUp2);
        btnNavigate2.setOnClickListener(v -> {
            Intent intent = new Intent(Login_Student.this, Sign_Up.class);
            startActivity(intent);

        });
    }
}